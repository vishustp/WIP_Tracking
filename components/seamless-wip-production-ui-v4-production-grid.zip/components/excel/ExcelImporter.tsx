'use client';

import { useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { createClient } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

type RawRow = Record<string, unknown>;
type ImportRow = {
  rowNo: number;
  work_order_no: string;
  customer_name: string | null;
  size_od: number | null;
  size_wt: number | null;
  grade: string | null;
  ordered_qty: number;
  uom: 'Pcs' | 'Mtrs';
  target_date: string | null;
  errors: string[];
  exists: boolean;
};

const aliases: Record<string, string[]> = {
  work_order_no: ['WO', 'Work Order', 'Work Order No', 'WO No', 'work_order_no'],
  customer_name: ['Customer', 'Customer Name', 'customer_name'],
  size_od: ['OD', 'Size OD', 'size_od'],
  size_wt: ['WT', 'Size WT', 'Wall Thickness', 'size_wt'],
  grade: ['Grade', 'Spec', 'Spec / Grade', 'grade'],
  ordered_qty: ['Qty', 'Quantity', 'Ordered Qty', 'Ordered Quantity', 'ordered_qty'],
  uom: ['UOM', 'Unit', 'uom'],
  target_date: ['Target Date', 'Due Date', 'Target', 'target_date'],
};

function norm(v: unknown) {
  return String(v ?? '').trim();
}
function key(v: string) {
  return v.toLowerCase().replace(/[^a-z0-9]/g, '');
}
function findValue(row: RawRow, names: string[]) {
  const entries = Object.entries(row);
  for (const name of names) {
    const hit = entries.find(([k]) => key(k) === key(name));
    if (hit) return hit[1];
  }
  return null;
}
function asNumber(v: unknown) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(String(v).replace(/,/g, '').trim());
  return Number.isFinite(n) ? n : null;
}
function asDate(v: unknown) {
  if (!v) return null;
  if (v instanceof Date && !Number.isNaN(v.getTime())) return v.toISOString().slice(0, 10);
  const s = norm(v);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
}

export default function ExcelImporter() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState('');
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [sheet, setSheet] = useState('');
  const [rawRows, setRawRows] = useState<RawRow[]>([]);
  const [rows, setRows] = useState<ImportRow[]>([]);
  const [mode, setMode] = useState<'skip' | 'update' | 'insert'>('skip');
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [result, setResult] = useState<{ total: number; valid: number; newRows: number; updated: number; skipped: number; failed: number } | null>(null);

  const validate = async (data: RawRow[]) => {
    const s = createClient();
    const woNos = data.map(r => norm(findValue(r, aliases.work_order_no))).filter(Boolean);
    const existing = new Set<string>();
    if (woNos.length) {
      const { data: found } = await s.from('work_orders').select('work_order_no').in('work_order_no', woNos);
      (found ?? []).forEach((x: { work_order_no: string }) => existing.add(x.work_order_no.trim().toLowerCase()));
    }

    const seen = new Set<string>();
    const parsed: ImportRow[] = data.map((r, i) => {
      const work_order_no = norm(findValue(r, aliases.work_order_no));
      const customer_name = norm(findValue(r, aliases.customer_name)) || null;
      const size_od = asNumber(findValue(r, aliases.size_od));
      const size_wt = asNumber(findValue(r, aliases.size_wt));
      const grade = norm(findValue(r, aliases.grade)) || null;
      const qty = asNumber(findValue(r, aliases.ordered_qty));
      const rawUom = norm(findValue(r, aliases.uom));
      const uom = rawUom.toLowerCase().startsWith('pc') ? 'Pcs' : 'Mtrs';
      const target_date = asDate(findValue(r, aliases.target_date));
      const errors: string[] = [];
      const duplicateInFile = work_order_no && seen.has(work_order_no.toLowerCase());

      if (!work_order_no) errors.push('Missing WO number');
      if (qty === null || qty <= 0) errors.push('Ordered Qty must be greater than 0');
      if (size_od !== null && size_od <= 0) errors.push('OD must be greater than 0');
      if (size_wt !== null && size_wt <= 0) errors.push('WT must be greater than 0');
      if (target_date === null && findValue(r, aliases.target_date)) errors.push('Invalid target date');
      if (duplicateInFile) errors.push('Duplicate WO in this file');
      if (work_order_no) seen.add(work_order_no.toLowerCase());

      return {
        rowNo: i + 2, work_order_no, customer_name, size_od, size_wt, grade,
        ordered_qty: qty ?? 0, uom, target_date, errors,
        exists: existing.has(work_order_no.toLowerCase()),
      };
    });
    setRows(parsed);
    setResult(null);
  };

  const parseWorkbook = async (file: File) => {
    setBusy(true);
    setResult(null);
    try {
      const buffer = await file.arrayBuffer();
      const wb = XLSX.read(buffer, { type: 'array', cellDates: true });
      setFileName(file.name);
      setSheetNames(wb.SheetNames);
      const first = wb.SheetNames[0] ?? '';
      setSheet(first);
      const data = first ? XLSX.utils.sheet_to_json<RawRow>(wb.Sheets[first], { defval: null }) : [];
      setRawRows(data);
      await validate(data);
      toast.success(`Loaded ${data.length} rows`);
    } catch {
      toast.error('Unable to read this workbook');
      setRawRows([]);
      setRows([]);
    } finally {
      setBusy(false);
    }
  };

  const changeSheet = async (name: string) => {
    setSheet(name);
    // Re-read the workbook by reusing the file input for simplicity.
    const file = inputRef.current?.files?.[0];
    if (!file) return;
    const wb = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: true });
    const data = XLSX.utils.sheet_to_json<RawRow>(wb.Sheets[name], { defval: null });
    setRawRows(data);
    await validate(data);
  };

  const validRows = useMemo(() => rows.filter(r => r.errors.length === 0), [rows]);
  const newRows = useMemo(() => validRows.filter(r => !r.exists), [validRows]);
  const existingRows = useMemo(() => validRows.filter(r => r.exists), [validRows]);

  const importRows = async () => {
    if (!validRows.length) {
      toast.error('There are no valid rows to import');
      return;
    }
    setBusy(true);
    const s = createClient();
    let inserted = 0, updated = 0, skipped = 0, failed = 0;

    try {
      for (const r of validRows) {
        if (r.exists && mode === 'skip') {
          skipped++;
          continue;
        }

        const payload = {
          work_order_no: r.work_order_no,
          customer_name: r.customer_name,
          size_od: r.size_od,
          size_wt: r.size_wt,
          grade: r.grade,
          ordered_qty: r.ordered_qty,
          uom: r.uom,
          target_date: r.target_date,
        };

        let error;
        if (r.exists && mode === 'update') {
          const res = await s.from('work_orders').update(payload).eq('work_order_no', r.work_order_no);
          error = res.error;
          if (!error) updated++;
        } else if (!r.exists) {
          const res = await s.from('work_orders').insert(payload);
          error = res.error;
          if (!error) inserted++;
        }

        if (error) {
          failed++;
          console.error('Import failed', r.rowNo, error);
        }
      }

      setResult({
        total: rows.length,
        valid: validRows.length,
        newRows: inserted,
        updated,
        skipped,
        failed,
      });
      if (failed) toast.error(`${failed} rows failed`);
      else toast.success('Import completed successfully');
    } finally {
      setBusy(false);
    }
  };

  const exportFailed = () => {
    const failed = rows.filter(r => r.errors.length);
    const out = failed.map(r => ({
      Row: r.rowNo,
      WO: r.work_order_no,
      Customer: r.customer_name ?? '',
      OD: r.size_od ?? '',
      WT: r.size_wt ?? '',
      Grade: r.grade ?? '',
      'Ordered Qty': r.ordered_qty || '',
      UOM: r.uom,
      'Target Date': r.target_date ?? '',
      Error: r.errors.join('; '),
    }));
    const ws = XLSX.utils.json_to_sheet(out);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Failed Rows');
    XLSX.writeFile(wb, 'failed-work-order-import.xlsx');
  };

  const reset = () => {
    setFileName(''); setSheetNames([]); setSheet(''); setRawRows([]); setRows([]); setResult(null);
    if (inputRef.current) inputRef.current.value = '';
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Excel Import</h1>
        <p className="text-sm text-slate-500">Bulk import Work Orders with preview, validation and duplicate control.</p>
      </div>

      <div
        className={`rounded-xl border-2 border-dashed p-8 text-center transition ${dragging ? 'border-slate-900 bg-slate-50' : 'border-slate-300 bg-white'}`}
        onDragOver={e => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={e => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files?.[0]; if (f) parseWorkbook(f); }}
      >
        <FileSpreadsheetIcon />
        <div className="font-semibold">Drop Excel file here</div>
        <div className="my-1 text-sm text-slate-500">or select an .xlsx, .xls or .csv file</div>
        <Button type="button" onClick={() => inputRef.current?.click()} disabled={busy}>
          {busy ? 'Processing…' : 'Choose File'}
        </Button>
        <input ref={inputRef} hidden type="file" accept=".xlsx,.xls,.csv" onChange={e => e.target.files?.[0] && parseWorkbook(e.target.files[0])} />
        {fileName && <div className="mt-3 text-xs text-slate-500">{fileName}</div>}
      </div>

      {sheetNames.length > 1 && (
        <div className="rounded-xl border bg-white p-4">
          <label className="mb-2 block text-sm font-medium">Sheet</label>
          <select className="rounded-md border px-3 py-2" value={sheet} onChange={e => changeSheet(e.target.value)}>
            {sheetNames.map(n => <option key={n}>{n}</option>)}
          </select>
        </div>
      )}

      {rows.length > 0 && (
        <>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <Stat label="Total" value={rows.length} />
            <Stat label="Valid" value={validRows.length} />
            <Stat label="Invalid" value={rows.length - validRows.length} />
            <Stat label="New WOs" value={newRows.length} />
            <Stat label="Existing WOs" value={existingRows.length} />
          </div>

          <div className="rounded-xl border bg-white p-5">
            <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
              <div>
                <h2 className="font-semibold">Import action</h2>
                <p className="text-sm text-slate-500">Existing Work Orders can be skipped or updated. Invalid rows are never imported.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <select className="rounded-md border px-3 py-2 text-sm" value={mode} onChange={e => setMode(e.target.value as typeof mode)}>
                  <option value="skip">Skip existing</option>
                  <option value="update">Update existing</option>
                  <option value="insert">Insert only new</option>
                </select>
                <Button type="button" onClick={exportFailed} disabled={!rows.some(r => r.errors.length)}>Export Failed Rows</Button>
                <Button type="button" onClick={reset}>Clear</Button>
                <Button type="button" onClick={importRows} disabled={busy || !validRows.length}>
                  {busy ? 'Importing…' : 'Confirm Import'}
                </Button>
              </div>
            </div>
          </div>

          {result && (
            <div className="rounded-xl border bg-emerald-50 p-4 text-sm">
              <strong>Import result:</strong> {result.newRows} new · {result.updated} updated · {result.skipped} skipped · {result.failed} failed
            </div>
          )}

          <div className="overflow-auto rounded-xl border bg-white">
            <table className="min-w-[1050px] w-full text-sm">
              <thead className="bg-slate-50">
                <tr>{['Row','WO','Customer','OD','WT','Grade','Qty','UOM','Target Date','Status','Error'].map(h => <th key={h} className="p-3 text-left">{h}</th>)}</tr>
              </thead>
              <tbody>
                {rows.slice(0, 200).map(r => (
                  <tr key={r.rowNo} className={`border-t ${r.errors.length ? 'bg-red-50' : ''}`}>
                    <td className="p-3">{r.rowNo}</td><td className="p-3 font-medium">{r.work_order_no || '—'}</td>
                    <td className="p-3">{r.customer_name || '—'}</td><td className="p-3">{r.size_od ?? '—'}</td>
                    <td className="p-3">{r.size_wt ?? '—'}</td><td className="p-3">{r.grade || '—'}</td>
                    <td className="p-3">{r.ordered_qty}</td><td className="p-3">{r.uom}</td>
                    <td className="p-3">{r.target_date || '—'}</td><td className="p-3">{r.errors.length ? 'Invalid' : r.exists ? 'Existing' : 'New'}</td>
                    <td className="p-3 text-red-600">{r.errors.join('; ') || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {rows.length > 200 && <div className="p-3 text-xs text-slate-500">Showing first 200 rows. All valid rows are still eligible for import.</div>}
          </div>
        </>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return <div className="rounded-xl border bg-white p-4"><div className="text-xs text-slate-500">{label}</div><div className="mt-1 text-2xl font-bold">{value}</div></div>;
}
function FileSpreadsheetIcon() {
  return <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100 text-slate-700"><span className="text-2xl">📊</span></div>;
}
