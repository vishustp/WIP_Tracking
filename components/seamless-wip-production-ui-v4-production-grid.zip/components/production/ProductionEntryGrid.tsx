'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { toast } from 'sonner';

type StageCode =
  | 'ROLLING'
  | 'HOLLOW_HEAT_TREATMENT'
  | 'DRAW'
  | 'HEAT_TREATMENT'
  | 'FINISHING';

type QueueRow = {
  work_order_id: string;
  work_order_no: string;
  customer_name: string | null;
  uom: 'Pcs' | 'Mtrs';
  route_id: string;
  route_code: string;
  route_name: string;
  stage_id: string;
  stage_code: StageCode;
  stage_name: string;
  sequence_no: number;
  balance_to_make: number;
};

type EntryRow = QueueRow & {
  input_qty: string;
  output_qty: string;
  rejection_qty: string;
  heat_lot_no: string;
  remarks: string;
};

const stageNames: Record<StageCode, string> = {
  ROLLING: 'Rolling',
  HOLLOW_HEAT_TREATMENT: 'Hollow Heat Treatment',
  DRAW: 'Draw',
  HEAT_TREATMENT: 'Heat Treatment',
  FINISHING: 'Finishing',
};

export default function ProductionEntryGrid({
  stageCode,
}: {
  stageCode: StageCode;
}) {
  const supabase = createClient();
  const [rows, setRows] = useState<EntryRow[]>([]);
  const [processDate, setProcessDate] = useState(
    new Date().toISOString().slice(0, 10)
  );
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.rpc('get_production_entry_queue', {
      p_stage_code: stageCode,
    });

    if (error) {
      toast.error(error.message);
      setRows([]);
    } else {
      setRows(
        ((data ?? []) as QueueRow[]).map((row) => ({
          ...row,
          input_qty: '',
          output_qty: '',
          rejection_qty: '',
          heat_lot_no: '',
          remarks: '',
        }))
      );
    }
    setLoading(false);
  };

  useEffect(() => {
    void load();
  }, [stageCode]);

  const update = (
    row: EntryRow,
    field: keyof Pick<
      EntryRow,
      'input_qty' | 'output_qty' | 'rejection_qty' | 'heat_lot_no' | 'remarks'
    >,
    value: string
  ) => {
    const key = `${row.work_order_id}-${row.route_id}`;
    setRows((current) =>
      current.map((item) =>
        `${item.work_order_id}-${item.route_id}` === key
          ? { ...item, [field]: value }
          : item
      )
    );
  };

  const save = async () => {
    const selected = rows.filter(
      (row) => Number(row.output_qty || 0) > 0 || Number(row.input_qty || 0) > 0
    );

    if (!selected.length) {
      toast.error('Enter production quantity for at least one order.');
      return;
    }

    for (const row of selected) {
      const input = Number(row.input_qty || 0);
      const output = Number(row.output_qty || 0);
      const rejection = Number(row.rejection_qty || 0);

      if (input < 0 || output < 0 || rejection < 0) {
        toast.error(`Invalid quantity for ${row.work_order_no}.`);
        return;
      }

      if (rejection > input) {
        toast.error(`Rejection cannot exceed input for ${row.work_order_no}.`);
        return;
      }

      if (input > row.balance_to_make) {
        toast.error(
          `${row.work_order_no} (${row.route_code}): input exceeds Balance to Make ${row.balance_to_make} ${row.uom}.`
        );
        return;
      }

      if (output > input) {
        toast.error(
          `${row.work_order_no}: output cannot exceed input in this entry.`
        );
        return;
      }
    }

    setSaving(true);
    try {
      for (const row of selected) {
        const { error } = await supabase.rpc('record_production', {
          p_work_order_id: row.work_order_id,
          p_route_id: row.route_id,
          p_stage_code: stageCode,
          p_process_date: processDate,
          p_input_qty: Number(row.input_qty || 0),
          p_output_qty: Number(row.output_qty || 0),
          p_rejection_qty: Number(row.rejection_qty || 0),
          p_heat_lot_no: row.heat_lot_no.trim() || null,
          p_remarks: row.remarks.trim() || null,
        });

        if (error) throw error;
      }

      toast.success(`${selected.length} production entry saved.`);
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Production entry failed.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">{stageNames[stageCode]} Production Entry</h1>
          <p className="text-sm text-muted-foreground">
            Only orders with Balance to Make are shown. Heat/Lot No. is optional.
          </p>
        </div>

        <label className="text-sm font-medium">
          Production Date
          <input
            type="date"
            value={processDate}
            onChange={(event) => setProcessDate(event.target.value)}
            className="ml-2 h-10 rounded-md border bg-background px-3"
          />
        </label>
      </div>

      <div className="overflow-x-auto rounded-xl border">
        <table className="min-w-[1250px] w-full text-sm">
          <thead className="bg-muted/50">
            <tr className="border-b">
              <th className="p-3 text-left">S.No.</th>
              <th className="p-3 text-left">Work Order</th>
              <th className="p-3 text-left">Customer</th>
              <th className="p-3 text-left">Route</th>
              <th className="p-3 text-left">UOM</th>
              <th className="p-3 text-right">Balance to Make</th>
              <th className="p-3 text-right">Input Qty</th>
              <th className="p-3 text-right">Output Qty</th>
              <th className="p-3 text-right">Rejection</th>
              <th className="p-3 text-left">Heat/Lot No.</th>
              <th className="p-3 text-left">Remarks</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={11} className="p-8 text-center">
                  Loading...
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={11} className="p-8 text-center">
                  No eligible orders for {stageNames[stageCode]}.
                </td>
              </tr>
            ) : (
              rows.map((row, index) => (
                <tr
                  key={`${row.work_order_id}-${row.route_id}`}
                  className="border-b"
                >
                  <td className="p-3">{index + 1}</td>
                  <td className="p-3 font-semibold">{row.work_order_no}</td>
                  <td className="p-3">{row.customer_name || '—'}</td>
                  <td className="p-3">{row.route_code}</td>
                  <td className="p-3 font-semibold">{row.uom}</td>
                  <td className="p-3 text-right font-semibold">
                    {Number(row.balance_to_make).toLocaleString()} {row.uom}
                  </td>
                  <td className="p-2">
                    <input
                      type="number"
                      min="0"
                      step="any"
                      className="h-9 w-32 rounded-md border px-2 text-right"
                      value={row.input_qty}
                      onChange={(event) =>
                        update(row, 'input_qty', event.target.value)
                      }
                    />
                  </td>
                  <td className="p-2">
                    <input
                      type="number"
                      min="0"
                      step="any"
                      className="h-9 w-32 rounded-md border px-2 text-right"
                      value={row.output_qty}
                      onChange={(event) =>
                        update(row, 'output_qty', event.target.value)
                      }
                    />
                  </td>
                  <td className="p-2">
                    <input
                      type="number"
                      min="0"
                      step="any"
                      className="h-9 w-28 rounded-md border px-2 text-right"
                      value={row.rejection_qty}
                      onChange={(event) =>
                        update(row, 'rejection_qty', event.target.value)
                      }
                    />
                  </td>
                  <td className="p-2">
                    <input
                      className="h-9 w-40 rounded-md border px-2"
                      placeholder="Optional"
                      value={row.heat_lot_no}
                      onChange={(event) =>
                        update(row, 'heat_lot_no', event.target.value)
                      }
                    />
                  </td>
                  <td className="p-2">
                    <input
                      className="h-9 w-48 rounded-md border px-2"
                      value={row.remarks}
                      onChange={(event) =>
                        update(row, 'remarks', event.target.value)
                      }
                    />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <button
        type="button"
        onClick={() => void save()}
        disabled={loading || saving || rows.length === 0}
        className="rounded-md border px-5 py-2 font-medium disabled:opacity-50"
      >
        {saving ? 'Saving...' : 'Save Production'}
      </button>
    </section>
  );
}
